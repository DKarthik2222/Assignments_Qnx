public class GradeMismatchException extends Exception {
	public GradeMismatchException(String s){
		super(s);
	}
}
