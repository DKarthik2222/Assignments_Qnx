public class PriceException extends Exception {
	public PriceException(String s){
		super(s);
	}
}
