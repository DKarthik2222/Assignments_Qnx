public class EssentialCommodityException extends Exception {
	public EssentialCommodityException(String s){
		super(s);
	}
}
